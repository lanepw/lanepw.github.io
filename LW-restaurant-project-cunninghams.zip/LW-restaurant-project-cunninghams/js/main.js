<script>
  jQuery("#gallery-heading").fitText();
</script>
